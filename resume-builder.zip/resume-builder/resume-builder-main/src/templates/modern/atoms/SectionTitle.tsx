export const SectionTitle = ({ label }: { label: string }) => {
  return <p className="text-lg font-normal">{label}</p>;
};
