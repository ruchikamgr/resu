export interface INavMenuItemProps {
  caption: string;
  popoverChildren: React.ReactNode;
}
